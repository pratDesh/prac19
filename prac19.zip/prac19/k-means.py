import numpy as np 
import matplotlib.pyplot as plt 
from sklearn.cluster import KMeans

x = np.array([[0.1,0.6],[0.15,0.7],[0.08,0.9],[0.16,0.85],[0.2,0.3],[0.25,0.5],[0.24,0.1],[0.3,0.2]])
initcenters = np.array([[0.1,0.6],[0.3,0.2]])

kmeans = KMeans(n_clusters=2, random_state=0, init=initcenters).fit(x)   #initial centers given in question else we can remove init
print(kmeans.labels_)
print(kmeans.cluster_centers_)

plt.scatter(x[:,0], x[:,1], c=kmeans.labels_, cmap='rainbow')
plt.scatter(kmeans.cluster_centers_[:,0], kmeans.cluster_centers_[:,1], color='green')
plt.show()

print(kmeans.predict([[0.25,0.5]]))

from collections import Counter
print(Counter(kmeans.labels_))

