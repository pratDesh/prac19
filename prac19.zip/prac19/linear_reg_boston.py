#!/usr/bin/env python
# coding: utf-8

# In[15]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split


# In[31]:


data = pd.read_csv('boston.csv')
data.head()


# In[12]:


X = data.iloc[:,:-1].values
Y = data.iloc[:,-1].values




# In[19]:


X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.2)



# In[30]:


lr = LinearRegression()
lr.fit(X_train,Y_train)
Y_pred = lr.predict(X_test)


# In[34]:


plt.plot(Y_pred,Y_test,'o')
plt.show()


# In[48]:


from sklearn.model_selection import cross_val_score
from sklearn.metrics import r2_score

print("Accuracy - ",lr.score(X,Y)*100)
print("R2 Score - ",r2_score(Y_test,Y_pred)*100)
print("CrossValidation Score - ",cross_val_score(lr,X,Y,cv=3))


# In[ ]:



# In[ ]:





# In[49]:


from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import ElasticNet
from sklearn.linear_model import Ridge


# In[54]:


clf = LinearRegression()
clf_lasso = Lasso()
clf_ridge = Ridge()
clf_enet = ElasticNet()



# In[55]:


clf.fit(X_train,Y_train)
clf_lasso.fit(X_train,Y_train)
clf_ridge.fit(X_train,Y_train)
clf_enet.fit(X_train,Y_train)



# In[56]:


pred = clf.predict(X_test)
pred_lasso = clf_lasso.predict(X_test)
pred_ridge = clf_ridge.predict(X_test)
pred_enet = clf_enet.predict(X_test)

pred_lasso = clf_lasso.predict(X_test)


# In[58]:


plt.plot(pred,Y_test,'o')
plt.plot(pred_lasso,Y_test,'o')
plt.plot(pred_ridge,Y_test,'o')
plt.plot(pred_enet,Y_test,'o')
plt.show()


# In[60]:


print("Accuracy - ",clf.score(X,Y)*100)
print("Accuracy - ",clf_lasso.score(X,Y)*100)
print("Accuracy - ",clf_ridge.score(X,Y)*100)
print("Accuracy - ",clf_enet.score(X,Y)*100)




# In[61]:


print("R2 Score - ",r2_score(Y_test,pred)*100)
print("R2 Score - ",r2_score(Y_test,pred_lasso)*100)
print("R2 Score - ",r2_score(Y_test,pred_ridge)*100)
print("R2 Score - ",r2_score(Y_test,pred_enet)*100)


# In[ ]:




