import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

from sklearn.cluster import KMeans
from sklearn import datasets

iris = datasets.load_iris()

X = iris.data[:, :2]
y = iris.target

model = KMeans(n_clusters=3)
model.fit(X)

plt.scatter(X[:,0], X[:,1], c=y, cmap='gist_rainbow')
plt.scatter(model.cluster_centers_[:,0],model.cluster_centers_[:,1],color='yellow')
plt.show()

print(model.labels_)

wcss = []

for i in range(1,11):
	kmeans = KMeans(n_clusters=i)
	kmeans.fit(X)
	wcss.append(kmeans.inertia_)

plt.plot(range(1,11), wcss)
plt.title('Elbow method')
plt.xlabel('No. of Class')
plt.ylabel('WCSS')
plt.show()


