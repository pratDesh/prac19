import random

def primitive_root(p):
	allNums = list(range(1,p))
	tempList=[]
	pri_root_list = []

	for g in range(1,p):
		for n in range(1,p):
			tempList.append(g**n%p)

		tempList = list(set(tempList))
		tempList.sort()

		if allNums == tempList:
			pri_root_list.append(g)

		tempList.clear()

	print(pri_root_list)
	return random.choice(pri_root_list)


p = int(input('Enter a prime Number '))
aplha = primitive_root(p)

print('aplha selected is : ',aplha)

X_A = int(input('Enter private key of Sender: '))
Y_A = aplha**X_A%p 

X_B = int(input("Enter private Key of Sender: "))
Y_B = aplha**X_B%p 

k_A = Y_B**X_A%p 
k_B = Y_A**X_B%p

print("\nsender A Private Key(X_A < q) :",X_A)
print("sender A Public Key :",Y_A)
print("\nreceiver B Private Key(X_B < q) :",X_B)
print("receiver B Public Key :",Y_B)
print("\nSecret Key at User A : ",k_A)
print("\nSecret Key at User B : ",k_B)