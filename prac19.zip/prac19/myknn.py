import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
#with split
Dataset=pd.read_csv('knn.csv')
x=Dataset.iloc[:,:-1].values
y=Dataset.iloc[:,2:3].values

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)

from sklearn.neighbors import KNeighborsClassifier
clf=KNeighborsClassifier(n_neighbors=3)
clf.fit(x_train,y_train)

y_pred_1=clf.predict([[6,6]])

y_pred=clf.predict(x_test)


####
#without split
from sklearn.neighbors import KNeighborsClassifier
from sklearn import preprocessing
model = KNeighborsClassifier(n_neighbors=3)
x=[[6,2],[4,4],[2,4],[4,2],[6,4],[4,6]]
y=['P','P','N','N','N','N']
le = preprocessing.LabelEncoder()
yl=le.fit_transform(y)

model.fit(x,yl)
predicted= model.predict([[6,6]])
