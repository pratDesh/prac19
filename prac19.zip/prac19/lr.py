import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt 

dataset = pd.read_csv('driving.csv')
print(dataset)

X = dataset.iloc[:, :-1].values
Y = dataset.iloc[:, 1].values 

from sklearn.linear_model import LinearRegression
  
regressor = LinearRegression()  
regressor.fit(X, Y)

print("intercept: ", regressor.intercept_)  
print("coef",regressor.coef_)  

y_pred = regressor.predict(X)

plt.scatter(X,Y ,color='r',s=30)
plt.plot(X,y_pred,color='g')
plt.title('Hours vs Risk_Score')
plt.xlabel('Hours') 
plt.ylabel('Risk_score')
plt.show()

