# -*- coding: utf-8 -*-
"""
Created on Sat Apr 13 11:55:56 2019

@author: Prakash
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
from sklearn.neighbors import KNeighborsClassifier
#from sklearn.preprocessing import LabelEncoder
Dataset=pd.read_csv('knn11.csv')

x=Dataset.iloc[:,:-1].values
y=Dataset.iloc[:,2].values


clf=KNeighborsClassifier(n_neighbors=3)
clf.fit(x,y)
x_test=np.array([[3,7]])		
y_pred=clf.predict(x_test)
print(y_pred)




