
plainText =  "01110010"
key =  "1010000010"
p10 = [3,5,2,7,4,10,1,9,8,6]   
p8  = [6,3,7,4,8,5,10,9] 
k1  = ""
k2  = ""
ip  = [2,6,3,1,4,8,5,7]
ep  = [4,1,2,3,2,3,4,1]
inverseip = [4,1,3,5,7,2,8,6]
p4 = [2,4,3,1]
sbox0 = [
			[ "01", "00", "11", "10" ],
			[ "11", "10", "01", "00" ],
			[ "00", "10", "01", "11" ],
			[ "11", "01", "11", "10" ]
		]
sbox1 = [
			[ "00", "01", "10", "11" ],
			[ "10", "00", "01", "11" ],
			[ "11", "00", "01", "00" ],
			[ "10", "00", "00", "11" ]
		]


def permute(message,table):
	return ''.join([message[table[i]-1] for i in range(len(table))])

def xor(l,r):
	return ''.join(['1' if l[i]!=r[i] else '0' for i in range(len(l))])

def rotate(message,times):
	for time in range(times):
		message = message[1:] + message[:1]
	return message

def s_box(m,sbox):
	rowIndex = int(m[0]+m[-1],2)
	colIndex = int(m[1]+m[2],2)
	return sbox[rowIndex][colIndex]

def gen_keys():
	global key,k1,k2
	print('Key is ',key)
	key = permute(key,p10)

	l0,r0 = key[0:5],key[5:]

	l1,r1 = rotate(l0,1) , rotate(r0,1)
	k1 = permute(l1+r1,p8)
	l2,r2 = rotate(l1,2) , rotate(r1,2)
	k2 = permute(l2+r2,p8)

def f(r,k):
	er = permute(r,ep)
	b0,b1 = xor(er,k)[0:4] , xor(er,k)[4:]
	result = s_box(b0,sbox0) + s_box(b1,sbox1)
	return permute(result,p4)

def sdes():
	permuted_text = permute(plainText,ip)
	gen_keys()
	l0,r0 = permuted_text[0:4] , permuted_text[4:]

	l1,r1 = r0 , xor(l0,f(r0,k1))
	l2,r2 = r1 , xor(l1,f(r1,k2))

	l2,r2 = r2,l2
	cipher = permute(l2+r2,inverseip)
	print(cipher)

sdes()
'''
p10 = [3,5,2,7,4,10,1,9,8,6]
p8 = [6,3,7,4,8,5,10,9]
p4 = [2,4,3,1]
IP8 = [2, 6, 3, 1, 4, 8, 5, 7]
EP = [4, 1, 2, 3, 2, 3, 4, 1]

S0 = [
    [1, 0, 3, 2],
        [3, 2, 1, 0],
        [0, 2, 1, 3],
        [3, 1, 3, 2]
     ]

S1 = [
        [0, 1, 2, 3],
        [2, 0, 1, 3],
        [3, 0, 1, 0],
        [2, 1, 0, 3]
     ]

def permute(pTab,key):
    permutedKey=[0]*len(pTab)
    j=0
    for i in pTab:
        permutedKey[j]=key[i-1]
        j=j+1
    return permutedKey 

def xor(x, y):
    xorList = [0]*len(x)
    for i in range(len(x)):
       xorList[i]=x[i]^y[i]
    return xorList

def generateFirstKey(left,right):
    leftRot = left[1:]+left[:1]
    rightRot = right[1:]+right[:1]
    rotKey = leftRot+rightRot
    return permute(p8,rotKey)

def generateSecondKey(left,right):
    leftRot = left[3:]+left[:3]
    rightRot = right[3:]+right[:3]
    rotKey = leftRot+rightRot
    return permute(p8,rotKey)

def Sbox(xor,S):
    row = int(str(xor[0]) + str(xor[3]), 2)
    column = int(str(xor[1]) + str(xor[2]), 2)
    Svalue = S[row][column]
    SList = [int(x) for x in bin(Svalue)[2:]]
    return SList

def F1(right,subkey):
    expanded = permute(EP,right)
    print("expanded ",expanded)
    xorCipher = xor(expanded,subkey)
    print(" xor ",xorCipher)
    leftxor = xorCipher[:4]
    rightxor = xorCipher[4:8]
    leftS0 = Sbox(leftxor,S0)
    rightS1 = Sbox(rightxor,S1)
    print("left S ",leftS0)
    print("right S ",rightS1)
    sboxOutput = leftS0+rightS1
    print("p4 out :",permute(p4,sboxOutput))
    return permute(p4,sboxOutput)

def repeatFunc(plain,key):
    print()
    permutedPlain = permute(IP8,plain)
    leftHalf = permutedPlain[:4]
    rightHalf = permutedPlain[4:8]
    print("f ",leftHalf)
    print("s ",rightHalf)
    p4out = F1(rightHalf,firstKey)
    xorLeft = xor(p4out,leftHalf)
    print("xorLeft ",xorLeft)
    combined = xorLeft+rightHalf
    return combined
   
print("Enter 8 bit plian text")
plain = map(int,raw_input().strip().split(" "))
print(plain)
print("Enter 10 bit key ")
key = map(int,raw_input().strip().split(" "))

p10key = permute(p10,key)
left = p10key[:5]
right = p10key[5:10]

firstKey = generateFirstKey(left,right)
secondKey = generateSecondKey(left,right)

print('firstKey ',firstKey)
print('secondKey ',secondKey)

combined = repeatFunc(plain,firstKey)
print("combined ",combined)

'''