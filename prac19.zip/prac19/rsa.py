from random import sample,randrange


def get_prime_list(n):
    prime_lst = []
    prime = [True for i in range(n+1)] 
    p = 2
    while (p * p <= n): 
        if (prime[p] == True): 
            for i in range(p * 2, n+1, p): 
                prime[i] = False
        p += 1
    for idx,value in enumerate(prime):
        if value:
            prime_lst.append(idx)
    return prime_lst[2:]


def gcd(a,b):
    if b==0:
        return a 
    return gcd(a,a%b)

M = 48
P, Q = sample(get_prime_list(100),2)

print(P,Q)
N = P*Q
phi = (P-1)*(Q-1)

# selecting e 
e = randrange(1, phi)
g = gcd(e, phi)
while g != 1:
    e = randrange(1, phi)
    g = gcd(e, phi)

print("e=",e)

# selecting d
x=1
while (phi*x+1)%e != 0:
    x=x+1

d = (phi*x+1)//e
print("d=",d)


M = "hellothere"

# Encryption
cipher = [(ord(char) ** e) % N for char in M]
print(cipher)

plain = [chr((char ** d) % N) for char in cipher]
print(plain)
print("".join(plain))
