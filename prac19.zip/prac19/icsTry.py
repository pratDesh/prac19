sbox = { 
		 "0000" : "1001" , "0001" : "0100" , "0010" : "1010" , "0011" : "1011" ,
		 "0100" : "1101" , "0101" : "0001" , "0110" : "1000" , "0111" : "0101" ,	
		 "1000" : "0110" , "1001" : "0010" , "1010" : "0000" , "1011" : "0011" ,		 
		 "1100" : "1100" , "1101" : "1110" , "1110" : "1111" , "1111" : "0111" 
	   }

key0 = "0100101011110101"
key1 = ""
key2 = ""
plaintext   = "1101011100101000"
roundConstant = ["","10000000","00110000"]

def xor(l,r):
	return ''.join(['1' if l[i]!=r[i] else '0' for i in range(len(l))])

def applysbox(b):
	return sbox[b]

def g(w,rnd):
	w = w[4:] + w[:4] #circular shift
	w = applysbox(w[:4]) + applysbox(w[4:])
	w = xor(w,roundConstant[rnd])
	return w

def gen_keys()
	global key0,key1,key2
	w0,w1 = key0[:8],key0[8:]

	w2 = xor(w0,g(w1,1))
	w3 = xor(w1,w2)
	key1 = w2+w3
	print("key1 ",key1)

	w4 = xor(w2,g(w3,2))
	w5 = xor(w4,w3) 
	key2 = w4+w5
	print('key2 ', key2)

def cross(b1,b2):

def bytesubstitution(b):
	return ''.join([applysbox(b[i:i+4]) for i in range(0,16,4)])

def mixcol(it,gf):
	return ''.

def saes():
	initTrans = xor(plaintext,key1)

	#Round 1
	initTrans = bytesubstitution(initTrans)
