import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 


'''
from sklearn import datasets

boston = datasets.load_boston()

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(boston.data, boston.target, test_size=0.3,random_state=23)

lr = LinearRegression()
lr.fit(X_train,y_train)
print(lr.score(X_test,y_test))

from sklearn.model_selection import cross_val_score

scores = cross_val_score(lr,boston.data,boston.target,cv=7,scoring='neg_mean_squared_error')

print(scores)
print(scores.mean())
print(scores.std())

from sklearn.linear_model import Lasso
ls = Lasso(alpha=0.001, normalize=True)
ls_scores = cross_val_score(ls, boston.data, boston.target, cv=10)
print(ls_scores)
print(ls_scores.mean())

from sklearn.linear_model import Ridge
clf=Ridge(alpha=100)
clf.fit(X_train,y_train)

rd_scores = cross_val_score(clf,boston.data, boston.target,cv=10)
print(rd_scores)
'''

from sklearn import datasets

boston = datasets.load_boston()

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(boston.data, boston.target, test_size=0.3, random_state=23)

lr = LinearRegression()
lr.fit(X_train,y_train)
print(lr.score(X_test,y_test))

y_pred = lr.predict(X_test)

plt.plot(y_pred,y_test,'o')
plt.show()


from sklearn.model_selection import cross_val_score

scores = cross_val_score(lr,boston.data,boston.target,cv=7)
print(scores)
print(scores.mean())
print(scores.std())

from sklearn.linear_model import Lasso
ls = Lasso(alpha=0.001, normalize=True)
ls_scores = cross_val_score(ls,boston.data,boston.target,cv=10)
print(ls_scores)
print(ls_scores.mean())

from sklearn.linear_model import Ridge
rd = Ridge(alpha=100)
rd.fit(X_train,y_train)

rd_scores = cross_val_score(rd,boston.data, boston.target,cv=10)
print(rd_scores)